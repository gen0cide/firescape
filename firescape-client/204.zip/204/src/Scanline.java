public class Scanline {

  int startX;
  int endX;
  int startS;
  int endS;

  public Scanline() {
  }
}
